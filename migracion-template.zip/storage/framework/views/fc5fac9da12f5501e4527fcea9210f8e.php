

<section id="project-area" class="project-area solid-bg">
    <div class="container">
        <div class="row text-center">
            <div class="col-lg-12">
                <h2 class="section-title">Además</h2>
                <h3 class="section-sub-title">Contamos con estos servicios</h3>
            </div>
        </div>
        <!--/ Title row end -->

        <div class="row">
            <div class="col-12">
                <div class="shuffle-btn-group">
                    <label class="active" for="all">
                        <input type="radio" name="shuffle-filter" id="all" value="all"
                            checked="checked">Mostrar todo
                    </label>
                    <label for="ingenieria">
                        <input type="radio" name="shuffle-filter" id="ingenieria" value="ingenieria">Ingeniería
                    </label>
                    <label for="geologia">
                        <input type="radio" name="shuffle-filter" id="geologia" value="geologia">Geología
                    </label>
                    <label for="seguridad">
                        <input type="radio" name="shuffle-filter" id="seguridad" value="seguridad">Seguridad
                    </label>
                    <label for="tecnicas">
                        <input type="radio" name="shuffle-filter" id="tecnicas" value="tecnicas">Técnicas y
                        procedimientos
                    </label>
                    <label for="investigacion"> <input type="radio" name="shuffle-filter" id="investigacion"
                            value="investigacion">Investigación
                    </label>
               </div><!-- project filter end -->


                <div class="row shuffle-wrapper">
                    <div class="col-1 shuffle-sizer"></div>

                    <div class="col-lg-4 col-md-6 shuffle-item" data-groups="[&quot;ingenieria&quot;]">
                        <div class="project-img-container">
                            <img class="img-fluid" src="images/projects/project1.jpg" alt="project-img">
                            <span class="gallery-icon"><i class="fa fa-plus"></i></span>

                            <div class="project-item-info">
                                <div class="project-item-info-content">
                                    <h3 class="project-item-title" style="color: white">Ingeniería</h3>
                                    <p class="project-cat" style= "font-size: 15px">Ejecución de proyectos de ingeniería
                                        y construcción de infraestructuras para la industria minera, con un enfoque
                                        en el uso eficiente de recursos naturales y energías renovables.</p>
                                </div>
                            </div>
                        </div>
                    </div><!-- shuffle item 1 end -->

                    <div class="col-lg-4 col-md-6 shuffle-item" data-groups="[&quot;geologia&quot;]">
                        <div class="project-img-container">

                            <img class="img-fluid" src="images/projects/project2.jpg" alt="project-img">
                            <span class="gallery-icon"><i class="fa fa-plus"></i></span>

                            <div class="project-item-info">
                                <div class="project-item-info-content">
                                    <h3 class="project-item-title" style="color: white">Geología</h3>
                                    <p class="project-cat" style="font-size: 15px">Estudio y asesoramiento en la exploración
                                       de recursos minerales, incluyendo los de factibilidad y evaluación de
                                        impacto ambiental.</p>
                                </div>
                            </div>
                        </div>
                    </div><!-- shuffle item 2 end -->

                    <div class="col-lg-4 col-md-6 shuffle-item" data-groups="[&quot;seguridad&quot;]">
                        <div class="project-img-container">
                            <img class="img-fluid" src="images/projects/project3.jpg" alt="project-img">
                            <span class="gallery-icon"><i class="fa fa-plus"></i></span>

                            <div class="project-item-info">
                                <div class="project-item-info-content">
                                    <h3 class="project-item-title" style="color: white">Seguridad</h3>
                                    <p class="project-cat" style="font-size: 15px">Asesoramiento en medidas de
                                        seguridad y prevención de riesgos en proyectos mineros, incluyendo capacitación
                                        y seguimiento constante.</p>
                                </div>
                            </div>
                        </div>
                    </div><!-- shuffle item 3 end -->

                    <div class="col-lg-4 col-md-6 shuffle-item" data-groups="[&quot;tecnicas&quot;]">
                        <div class="project-img-container">
                            <img class="img-fluid" src="images/projects/project4.jpg" alt="project-img">
                            <span class="gallery-icon"><i class="fa fa-plus"></i></span>

                            <div class="project-item-info">
                                <div class="project-item-info-content">
                                    <h3 class="project-item-title" style="color: white">Técnicas y procedimientos</h3>
                                    <p class="project-cat" style="font-size: 15px">Desarrollo e implementación de
                                        técnicas y procedimientos innovadores para la extracción y procesamiento de
                                        minerales, con un enfoque en la sostenibilidad y reducción de impacto
                                        ambiental.</p>
                                </div>
                            </div>
                        </div>
                    </div><!-- shuffle item 4 end -->

                    <div class="col-lg-4 col-md-6 shuffle-item" data-groups="[&quot;investigacion&quot;]">
                        <div class="project-img-container">
                            <img class="img-fluid" src="images/projects/project5.jpg" alt="project-img">
                            <span class="gallery-icon"><i class="fa fa-plus"></i></span>

                            <div class="project-item-info">
                                <div class="project-item-info-content">
                                    <h3 class="project-item-title" style="color: white">Investigación</h3>
                                    <p class="project-cat" style="font-size: 15px">Investigación y desarrollo de nuevas
                                        tecnologías y métodos para la industria minera, con un enfoque en la
                                        eficiencia y sostenibilidad.</p>
                                </div>
                            </div>
                        </div>
                    </div><!-- shuffle item 5 end -->

                    <!-- <div class="col-lg-4 col-md-6 shuffle-item" data-groups="[&quot;residential&quot;]">
              <div class="project-img-container">
                <img class="img-fluid" src="images/projects/project6.jpg" alt="project-img">
                <span class="gallery-icon"><i class="fa fa-plus"></i></span>
                
                <div class="project-item-info">
                  <div class="project-item-info-content">
                    <h3 class="project-item-title">Residential</h3>
                    <p class="project-cat">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                  </div>
                </div>
              </div>
            </div> -->
                    <!-- shuffle item 6 end -->

                    <!-- <div class="col-lg-4 col-md-6 shuffle-item" data-groups="[&quot;healthcare&quot;]">
              <div class="project-img-container">
                <img class="img-fluid" src="images/projects/project7.jpg" alt="project-img">
                <span class="gallery-icon"><i class="fa fa-plus"></i></span>
                
                <div class="project-item-info">
                  <div class="project-item-info-content">
                    <h3 class="project-item-title">Healthcare</h3>
                    <p class="project-cat">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                  </div>
                </div>
              </div>
            </div> -->
                    <!-- shuffle item 7 end -->
                </div><!-- shuffle end -->

            </div><!-- col end -->
        </div><!-- row end-->
    </div>
</section>
<?php /**PATH C:\xampp\htdocs\laravel\Mining-solutions\migracion-template\resources\views/_components/section-project-area.blade.php ENDPATH**/ ?>