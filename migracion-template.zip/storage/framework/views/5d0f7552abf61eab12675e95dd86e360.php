<!--<section style="margin: 20px; padding: 0px">
  <div style="width: 100%; background-color: #005E76; border: 1px solid #005E76;">
    <h2 style="color: #fff; text-align: left; padding: 10px;">Principales marcas con las que trabajamos:</h2>
    <div style="display: flex; justify-content: space-between; align-items: center; padding: 10px;">
      <img src="images/marcas/caterpillar.jpg" alt="Caterpillar" style="width: 243.6px; height: 60px;">
      <img src="images/marcas/john-deere.jpg" alt="John Deere" style="width: 72.45px; height: 60px;">
      <img src="images/marcas/fucheng.jpg" alt="Fucheng" style="width: 60px; height: 60px;">
      <img src="images/marcas/toyota.jpg" alt="Toyota" style="width: 319.95px; height: 60px;">
      <img src="images/marcas/makita.jpg" alt="Makita" style="width: 195.45px; height: 60px;">
      <img src="images/marcas/dewalt.jpg" alt="Dewalt" style="width: 196.8px; height: 60px;">
    </div>
  </div>
</section>



 <section id="facts" class="facts-area dark-bg">
    <div class="container">
      <div class="facts-wrapper">
          <div class="row">
            <div class="col-md-3 col-sm-6 ts-facts">
                <div class="ts-facts-img">
                  <img loading="lazy" src="images/icon-image/fact1.png" alt="facts-img">
                </div>
                <div class="ts-facts-content">
                  <h2 class="ts-facts-num"><span class="counterUp" data-count="1789">0</span></h2>
                  <h3 class="ts-facts-title">Colaboración total en proyectos.</h3>
                </div>
            </div>
  
            <div class="col-md-3 col-sm-6 ts-facts mt-5 mt-sm-0">
                <div class="ts-facts-img">
                  <img loading="lazy" src="images/icon-image/fact2.png" alt="facts-img">
                </div>
                <div class="ts-facts-content">
                  <h2 class="ts-facts-num"><span class="counterUp" data-count="647">0</span></h2>
                  <h3 class="ts-facts-title">Miembros de nuestro equipo</h3>
                </div>
            </div>
  
            <div class="col-md-3 col-sm-6 ts-facts mt-5 mt-md-0">
                <div class="ts-facts-img">
                  <img loading="lazy" src="images/icon-image/fact3.png" alt="facts-img">
                </div>
                <div class="ts-facts-content">
                  <h2 class="ts-facts-num"><span class="counterUp" data-count="4000">0</span></h2>
                  <h3 class="ts-facts-title">Horas de trabajo</h3>
                </div>
            </div>
  
            <div class="col-md-3 col-sm-6 ts-facts mt-5 mt-md-0">
                <div class="ts-facts-img">
                  <img loading="lazy" src="images/icon-image/fact4.png" alt="facts-img">
                </div>
                <div class="ts-facts-content">
                  <h2 class="ts-facts-num"><span class="counterUp" data-count="44">0</span></h2>
                  <h3 class="ts-facts-title">proyectos exitosos en nuestra zona de influencia</h3>
                </div>
            </div>
  
          </div>
      </div>
      
    </div>

  </section>--><?php /**PATH C:\xampp\htdocs\laravel\Mining-solutions\migracion-template\resources\views/_components/section-facts.blade.php ENDPATH**/ ?>