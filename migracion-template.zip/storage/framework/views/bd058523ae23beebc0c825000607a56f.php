<section class="content dark-bg">
    <div class="container">
      <div class="row">
          <div class="col-12">
  
            <h3 class="column-title">Principales marcas</h3>
  
            <div class="row all-clients">
                <div class="col-md-2 col-sm-3 col-6">
                  <figure class="clients-logo">
                      <a href="#!"><img loading="lazy" class="img-fluid" src="<?php echo e(asset('images/marcas/caterpillarlogobla.png')); ?>" alt="clients-logo" /></a>
                  </figure>
                </div><!-- Client 1 end -->
  
                <div class="col-md-2 col-sm-3 col-6">
                  <figure class="clients-logo">
                      <a href="#!"><img loading="lazy" class="img-fluid" src="<?php echo e(asset('images/marcas/john-deere-logo-1.png')); ?>" alt="clients-logo" /></a>
                  </figure>
                </div><!-- Client 2 end -->
  
                <div class="col-md-2 col-sm-3 col-6">
                  <figure class="clients-logo">
                      <a href="#!"><img loading="lazy" class="img-fluid" src="<?php echo e(asset ('images/marcas/Komatsu-Logo.png')); ?>" alt="clients-logo" /></a>
                  </figure>
                </div><!-- Client 3 end -->
  
                <div class="col-md-2 col-sm-3 col-6">
                  <figure class="clients-logo">
                      <a href="#!"><img loading="lazy" class="img-fluid" src="<?php echo e(asset ('images/marcas/hyundai.png')); ?>" alt="clients-logo" /></a>
                  </figure>
                </div><!-- Client 4 end -->
  
                <div class="col-md-2 col-sm-3 col-6">
                  <figure class="clients-logo">
                      <a href="#!"><img loading="lazy" class="img-fluid" src="<?php echo e(asset ('images/marcas/dewalt.jpg')); ?>" alt="clients-logo" /></a>
                  </figure>
                </div><!-- Client 5 end -->
  
                <div class="col-md-2 col-sm-3 col-6">
                  <figure class="clients-logo">
                      <a href="#!"><img loading="lazy" class="img-fluid" src="<?php echo e(asset ('images/marcas/caseLogo3D.png')); ?>" alt="clients-logo" /></a>
                  </figure>
                </div><!-- Client 6 end -->
  
            </div><!-- Clients row end -->
  
          </div><!-- Col end -->
  
      </div>
      <!--/ Content row end -->
    </div>
    <!--/ Container end -->
  </section><!-- Content end --><?php /**PATH C:\xampp\htdocs\laravel\Mining-solutions\migracion-template\resources\views/_components/marcas.blade.php ENDPATH**/ ?>