<header id="header" class="header-one">
<?php echo $__env->make('layouts._partials._subpartials.header-company-description', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts._partials._subpartials.header-site-navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--/ Navigation end -->
</header>
<?php /**PATH C:\xampp\htdocs\laravel\Mining-solutions\migracion-template\resources\views/layouts/_partials/header.blade.php ENDPATH**/ ?>