<div class="ts-service-box d-flex">
    <div class="ts-service-box-img">
        <img loading="lazy" src="<?php echo e($directory); ?>" alt="service-icon">
    </div>
    <div class="ts-service-box-info">
        <h3 class="service-box-title"><a href="#"><?php echo e($title); ?></a></h3>
        <p><b><?php echo e($content); ?></b> </p>
    </div>
</div><!-- service end --><?php /**PATH C:\xampp\htdocs\laravel\Mining-solutions\migracion-template\resources\views/_components/_subcomponents/ts-service-box.blade.php ENDPATH**/ ?>