<!-- 
Muestra una tarjeta: Una imagen, debajo un h2 y debajo un párrafo.
Recibe tres parámetros: 
  El directorio de la imagen: $service['directory']
  El título del servicio: $service['title'] 
  El contenido del servicio: $service['content']
-->
<div class="col-lg-4 col-md-6 mb-5">
  <div class="ts-service-box">
      <div class="ts-service-image-wrapper">
        <img loading="lazy" class="w-100" src=<?php echo e($service['directory']); ?> alt="service-image">
      </div>
      <div class="d-flex">
        <div class="ts-service-box-img">
        </div>
        <div class="ts-service-info">
            <h3 class="service-box-title"><?php echo e($service['title']); ?></h3>
            <p><?php echo e($service['content']); ?></p>                    
        </div>
      </div>
  </div><!-- Service end -->
</div><?php /**PATH C:\xampp\htdocs\laravel\Mining-solutions\migracion-template\resources\views/_components/service-card.blade.php ENDPATH**/ ?>