<?php $__env->startSection('top-layer'); ?>
    <!-- el banner de arriba con la direccion y las redes sociales -->
    <?php $__env->startComponent('_components.top-bar'); ?>
    <?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('banners'); ?>
    <!-- el carrousel de fotos principal -->
    <?php $__env->startComponent('_components.banner-carousel'); ?>
    <?php echo $__env->renderComponent(); ?>
     <!-- la franja divisora celeste con el botón contacto -->
    <?php $__env->startComponent('_components.banner-contact'); ?>
    <?php echo $__env->renderComponent(); ?>
    <!-- el about us -->
    <?php $__env->startComponent('_components.banner-features'); ?>
    <?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('sections'); ?>
    <!-- Marcas -->
    <?php $__env->startComponent('_components.marcas'); ?>
    <?php echo $__env->renderComponent(); ?>
    <!-- que es lo que hacemos -->
    <?php $__env->startComponent('_components.section-ts-service-area'); ?>
    <?php echo $__env->renderComponent(); ?>
   <!-- minerales y publicidad -->
   <?php $__env->startComponent('_components.extra-services'); ?>
   <?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.landing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\Mining-solutions\migracion-template\resources\views/index.blade.php ENDPATH**/ ?>