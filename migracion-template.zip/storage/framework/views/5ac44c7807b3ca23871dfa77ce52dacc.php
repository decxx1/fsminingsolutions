<!DOCTYPE html>
<html lang="es">

<!-- HEAD -->
<?php echo $__env->make('layouts._partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- END HEAD -->


<body>
    
    <div class="body-inner">

        <?php echo $__env->yieldContent('top-layer'); ?>:

        <!-- HEADER -->
        <?php echo $__env->make('layouts._partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- END HEADER -->

        <?php echo $__env->yieldContent('banners'); ?>;
        <?php echo $__env->yieldContent('sections'); ?>

        <!-- FOOTER -->
        <?php echo $__env->make('layouts._partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- END FOOTER -->

    </div><!-- Body inner end -->

    <!-- JAVASCRIPT -->
    <?php echo $__env->make('layouts._partials.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- END JAVASCRIPT -->
    
</body>

</html>
<?php /**PATH C:\xampp\htdocs\laravel\Mining-solutions\migracion-template\resources\views/layouts/landing.blade.php ENDPATH**/ ?>