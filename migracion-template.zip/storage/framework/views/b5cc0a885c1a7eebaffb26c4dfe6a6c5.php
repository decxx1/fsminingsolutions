<section class="subscribe no-padding">
    <div class="container">
      <div class="row">
          <div class="col-lg-4">
            <div class="subscribe-call-to-acton">
                <h3>¿En qué podemos ayudarte?</h3>
                <h4>(+54) 11-44138057</h4>
            </div>
          </div><!-- Col end -->
  
          <div class="col-lg-8">
            <div class="ts-newsletter row align-items-center">
                <div class="col-md-5 newsletter-introtext">
                  <h4 class="text-white mb-0">Suscíbete a nuestro boletín informativo</h4>
                  <p class="text-white">Últimas actualizaciones y noticias</p>
                </div>
  
                <div class="col-md-7 newsletter-form">
                  <form action="#" method="post">
                      <div class="form-group">
                        <label for="newsletter-email" class="content-hidden">Newsletter Email</label>
                        <input type="email" name="email" id="newsletter-email" class="form-control form-control-lg" placeholder="Escribe tu e-mail y presiona ENTER" autocomplete="off">
                      </div>
                  </form>
                </div>
            </div><!-- Newsletter end -->
          </div><!-- Col end -->
  
      </div><!-- Content row end -->
    </div>
    <!--/ Container end -->
  </section>
  <!--/ subscribe end --><?php /**PATH C:\xampp\htdocs\laravel\Mining-solutions\migracion-template\resources\views/_components/section-subscribe.blade.php ENDPATH**/ ?>