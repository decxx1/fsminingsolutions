<div class="ts-service-box d-flex">
    <div class="ts-service-box-img">
        <img loading="lazy" src="{{ $directory }}" alt="service-icon">
    </div>
    <div class="ts-service-box-info">
        <h3 class="service-box-title"><a href="#">{{ $title }}</a></h3>
        <p><b>{{ $content }}</b> </p>
    </div>
</div><!-- service end -->